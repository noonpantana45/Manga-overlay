package com.mangaoverlay.app

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private const val REQ_CAPTURE = 1
        private const val REQ_NOTIF = 2
        private const val INK = 0xFF1A2030.toInt()
        private const val MUTED = 0xFF5A6377.toInt()
        private const val ACCENT = 0xFF0F7B6C.toInt()
        private const val STOP = 0xFF8A3B32.toInt()
        private const val SLATE = 0xFF3D4A63.toInt()
        private const val BG = 0xFFF3F5F8.toInt()
    }

    private val sources = arrayOf("auto", "ja", "zh", "ko", "en")
    private val sourceLabels = arrayOf("ตรวจภาษาอัตโนมัติ", "ญี่ปุ่น", "จีน", "เกาหลี", "อังกฤษ")
    private val toneLabels = arrayOf("ตามบุคลิกตัวละคร (แนะนำ)", "เป็นกันเอง", "สุภาพ")
    private val sizeLabels = arrayOf("เล็ก", "กลาง", "ใหญ่")
    private val themeLabels = arrayOf("พื้นขาวตัวดำ (มาตรฐานมังงะ)", "พื้นดำตัวขาว (เว็บตูนพื้นมืด)", "กึ่งโปร่งใส")

    private lateinit var status: TextView
    private lateinit var permView: TextView
    private lateinit var usage: TextView
    private lateinit var keyEdit: EditText
    private lateinit var testBtn: Button
    private lateinit var testResult: TextView
    private lateinit var modelEdit: EditText
    private lateinit var glossaryEdit: EditText
    private lateinit var sourceSpin: Spinner
    private lateinit var toneSpin: Spinner
    private lateinit var sizeSpin: Spinner
    private lateinit var themeSpin: Spinner
    private lateinit var autoSwitch: Switch
    private lateinit var sfxCheck: CheckBox
    private lateinit var honorCheck: CheckBox
    private lateinit var tapExpandCheck: CheckBox
    private lateinit var errView: TextView
    private var pendingStart = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Prefs.load(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(24), dp(20), dp(40))

        root.addView(tv("แปลมังงะบนจอ", 28f, true, INK))
        root.addView(tv("ปุ่มลอยที่แปลช่องคำพูดเป็นภาษาไทย ใช้ได้กับทุกแอปและทุกเว็บ", 15f, false, MUTED), lp(4))

        status = tv("", 16f, true, INK)
        root.addView(status, lp(20))
        permView = tv("", 13f, false, MUTED)
        root.addView(permView, lp(2))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val startLp = LinearLayout.LayoutParams(0, dp(56), 1f)
        startLp.rightMargin = dp(6)
        val stopLp = LinearLayout.LayoutParams(0, dp(56), 1f)
        stopLp.leftMargin = dp(6)
        row.addView(bigButton("เริ่ม", ACCENT) { onStartPressed() }, startLp)
        row.addView(bigButton("หยุด", STOP) { onStopPressed() }, stopLp)
        root.addView(row, lp(12))

        usage = tv("", 14f, false, MUTED)
        root.addView(usage, lp(8))

        root.addView(tv("วิธีใช้", 18f, true, INK), lp(28))
        root.addView(
            tv(
                "1. ใส่ Gemini API key ด้านล่าง (ขอได้ฟรี) แล้วกด ทดสอบ key
" +
                    "2. กด เริ่ม แล้วอนุญาตให้แสดงทับแอปอื่นและบันทึกหน้าจอ
" +
                    "3. เปิดแอปหรือเว็บมังงะ แล้วแตะปุ่มลอยเพื่อแปลทั้งหน้า
" +
                    "4. แตะปุ่มอีกครั้งเพื่อซ่อนคำแปล ลากเพื่อย้ายปุ่ม
" +
                    "5. ตอนมีคำแปลอยู่ แตะค้างที่ปุ่มเพื่อแอบดูต้นฉบับ
" +
                    "6. ตอนไม่มีคำแปล แตะค้างที่ปุ่มเพื่อเปิดเมนูด่วน: แปลเฉพาะจุด (ลากกรอบคลุม), ขยายคำแปล, เปิด/ปิดออโต้ หรือหยุดแอป
" +
                    "7. เลื่อนจอแล้วคำแปลจะหายเอง
" +
                    "8. ปุ่มสีม่วงแปลว่าใช้โหมดสำรองในเครื่อง (ไม่มี key หรือโควตาฟรีหมด) ถ้าปุ่มค้างสีส้ม แตะอีกครั้งเพื่อยกเลิก",
                15f, false, INK
            ), lp(6)
        )

        root.addView(tv("Gemini API key", 18f, true, INK), lp(28))
        keyEdit = edit(p.apiKey, "วาง API key ที่นี่")
        keyEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        root.addView(keyEdit, lp(6))
        val getKey = bigButton("ขอ API key ฟรีจาก Google AI Studio", SLATE) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
            } catch (_: Exception) {
                toast("เปิดเบราว์เซอร์ไม่ได้")
            }
        }
        getKey.textSize = 15f
        root.addView(getKey, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).also { it.topMargin = dp(8) })
        testBtn = bigButton("ทดสอบ key", SLATE) { testKey() }
        testBtn.textSize = 15f
        root.addView(testBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).also { it.topMargin = dp(8) })
        testResult = tv("", 14f, false, MUTED)
        root.addView(testResult, lp(6))

        root.addView(tv("ตั้งค่าการแปล", 18f, true, INK), lp(28))
        root.addView(tv("ภาษาต้นฉบับ", 14f, false, MUTED), lp(10))
        sourceSpin = spinner(sourceLabels, sources.indexOf(p.source).coerceAtLeast(0))
        root.addView(sourceSpin, lp(2))

        root.addView(tv("น้ำเสียงของคำแปล", 14f, false, MUTED), lp(12))
        toneSpin = spinner(toneLabels, p.tone.coerceIn(0, 2))
        root.addView(toneSpin, lp(2))

        autoSwitch = Switch(this)
        autoSwitch.text = "แปลอัตโนมัติเมื่อหยุดเลื่อน"
        autoSwitch.textSize = 15f
        autoSwitch.setTextColor(INK)
        autoSwitch.isChecked = p.auto
        root.addView(autoSwitch, lp(16))
        root.addView(
            tv(
                "ระวัง: ขณะเปิดออโต้ ทุกหน้าจอที่หยุดนิ่ง (รวมแชทและแอปอื่น) จะถูกส่งไปแปล และกินโควตาเร็ว " +
                    "แนะนำให้เปิดเฉพาะตอนอ่านมังงะ แล้วปิดตอนเลิกอ่าน",
                13f, false, STOP
            ), lp(2)
        )

        sfxCheck = check("แปลเสียงประกอบ (SFX) ด้วย", p.sfx)
        root.addView(sfxCheck, lp(10))
        honorCheck = check("คงคำเรียกแบบต้นฉบับ เช่น ซัง คุง โอปป้า", p.honorifics)
        root.addView(honorCheck, lp(4))
        tapExpandCheck = check("แตะที่กล่องคำแปลเพื่อขยายอ่านชัด ๆ และคัดลอกคำศัพท์", p.tapExpand)
        root.addView(tapExpandCheck, lp(4))

        root.addView(tv("ขนาดตัวอักษรคำแปล", 14f, false, MUTED), lp(12))
        sizeSpin = spinner(sizeLabels, p.fontSize.coerceIn(0, 2))
        root.addView(sizeSpin, lp(2))

        root.addView(tv("สีพื้นหลังกล่องคำแปล", 14f, false, MUTED), lp(12))
        themeSpin = spinner(themeLabels, p.bubbleTheme.coerceIn(0, 2))
        root.addView(themeSpin, lp(2))

        root.addView(tv("ชื่อตัวละคร บรรทัดละชื่อ เช่น Haruto = ฮารุโตะ", 14f, false, MUTED), lp(14))
        glossaryEdit = edit(p.glossary, "ชื่อต้นฉบับ = ชื่อภาษาไทย")
        glossaryEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        glossaryEdit.minLines = 3
        glossaryEdit.gravity = Gravity.TOP or Gravity.START
        root.addView(glossaryEdit, lp(2))

        root.addView(tv("โมเดล Gemini (ปกติไม่ต้องแก้ ถ้าโมเดลหลักโควตาหมดแอปจะลองโมเดลสำรองให้เอง)", 14f, false, MUTED), lp(14))
        modelEdit = edit(p.model, Prefs.DEFAULT_MODEL)
        modelEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        root.addView(modelEdit, lp(2))

        root.addView(tv("ให้แอปทำงานได้นาน", 18f, true, INK), lp(28))
        root.addView(
            tv(
                "บางยี่ห้อ (Xiaomi, Oppo, Vivo, Huawei, Samsung) อาจปิดแอปเบื้องหลังเพื่อประหยัดแบตเตอรี่ " +
                    "ถ้าปุ่มลอยหายไปเอง ให้ตั้งแอปนี้เป็น ไม่จำกัด หรือ ไม่เพิ่มประสิทธิภาพ",
                14f, false, MUTED
            ), lp(6)
        )
        val battery = bigButton("เปิดตั้งค่าแบตเตอรี่", SLATE) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATIONS_SETTINGS))
            } catch (_: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                } catch (_: Exception) {
                    toast("เปิดหน้าตั้งค่าไม่ได้")
                }
            }
        }
        battery.textSize = 15f
        root.addView(battery, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).also { it.topMargin = dp(8) })

        root.addView(
            tv(
                "เรื่องความเป็นส่วนตัว: ตอนแปลด้วย Gemini ภาพหน้าจอจะถูกส่งไปที่ Google และในระดับฟรี Google อาจนำข้อมูลไปปรับปรุงบริการ " +
                    "อย่ากดแปลตอนที่มีแชทหรือข้อมูลส่วนตัวอยู่บนจอ API key เก็บไว้ในที่เก็บข้อมูลส่วนตัวของแอปนี้ในเครื่องเท่านั้น (ไม่ได้เข้ารหัสเพิ่ม)",
                13f, false, MUTED
            ), lp(24)
        )

        root.addView(tv("บันทึกข้อผิดพลาดล่าสุด", 18f, true, INK), lp(28))
        errView = tv("", 13f, false, INK)
        errView.setTextIsSelectable(true)
        root.addView(errView, lp(6))
        val errRow = LinearLayout(this)
        errRow.orientation = LinearLayout.HORIZONTAL
        val copyLp = LinearLayout.LayoutParams(0, dp(46), 1f)
        copyLp.rightMargin = dp(6)
        val clearLp = LinearLayout.LayoutParams(0, dp(46), 1f)
        clearLp.leftMargin = dp(6)
        val copyBtn = bigButton("คัดลอก", SLATE) { copyError() }
        copyBtn.textSize = 15f
        val clearBtn = bigButton("ล้าง", SLATE) {
            Prefs.clearError(this)
            refresh()
        }
        clearBtn.textSize = 15f
        errRow.addView(copyBtn, copyLp)
        errRow.addView(clearBtn, clearLp)
        root.addView(errRow, lp(8))

        root.addView(tv("เวอร์ชัน 1.2", 12f, false, MUTED), lp(20))

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        super.onPause()
        save()
    }

    private fun refresh() {
        val p = Prefs.load(this)
        autoSwitch.isChecked = p.auto
        tapExpandCheck.isChecked = p.tapExpand
        if (OverlayService.running) {
            status.text = "● กำลังทำงาน"
            status.setTextColor(ACCENT)
        } else {
            status.text = "○ หยุดอยู่"
            status.setTextColor(MUTED)
        }
        permView.text = if (Settings.canDrawOverlays(this)) {
            "สิทธิ์แสดงทับแอปอื่น: เปิดแล้ว"
        } else {
            "สิทธิ์แสดงทับแอปอื่น: ยังไม่เปิด (จะขอตอนกด เริ่ม)"
        }
        usage.text = "วันนี้แปลด้วย Gemini ไปแล้ว " + Prefs.usesToday(this) + " ครั้ง"
        val e = Prefs.lastError(this)
        errView.text = if (e.isEmpty()) "ไม่มีข้อผิดพลาดที่บันทึกไว้" else e
    }

    private fun save() {
        Prefs.save(
            this, Prefs.Snapshot(
                apiKey = keyEdit.text.toString().trim(),
                model = modelEdit.text.toString().trim().ifEmpty { Prefs.DEFAULT_MODEL },
                source = sources[sourceSpin.selectedItemPosition.coerceIn(0, sources.size - 1)],
                auto = autoSwitch.isChecked,
                sfx = sfxCheck.isChecked,
                honorifics = honorCheck.isChecked,
                fontSize = sizeSpin.selectedItemPosition.coerceIn(0, 2),
                tone = toneSpin.selectedItemPosition.coerceIn(0, 2),
                bubbleTheme = themeSpin.selectedItemPosition.coerceIn(0, 2),
                tapExpand = tapExpandCheck.isChecked,
                glossary = glossaryEdit.text.toString()
            )
        )
    }

    private fun testKey() {
        save()
        val key = keyEdit.text.toString().trim()
        if (key.isEmpty()) {
            toast("ใส่ API key ก่อน")
            return
        }
        val model = modelEdit.text.toString()
        testBtn.isEnabled = false
        testResult.setTextColor(MUTED)
        testResult.text = "กำลังทดสอบ…"
        Thread {
            val msg = try {
                Translator.testKey(key, model)
            } catch (e: Exception) {
                "เชื่อมต่อไม่ได้ ตรวจอินเทอร์เน็ต (" + e.javaClass.simpleName + ")"
            }
            runOnUiThread {
                testBtn.isEnabled = true
                testResult.text = msg
                testResult.setTextColor(if (msg.startsWith("ใช้งานได้") || msg.startsWith("key ใช้ได้")) ACCENT else STOP)
            }
        }.start()
    }

    private fun copyError() {
        val e = Prefs.lastError(this)
        if (e.isEmpty()) {
            toast("ไม่มีข้อผิดพลาดให้คัดลอก")
            return
        }
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("error", e))
        toast("คัดลอกแล้ว")
    }

    private fun onStartPressed() {
        save()
        if (OverlayService.running) {
            toast("กำลังทำงานอยู่แล้ว เปิดแอปมังงะแล้วแตะปุ่มลอยได้เลย")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("เปิดสิทธิ์ แสดงทับแอปอื่น ให้แอปนี้ แล้วกลับมากดเริ่มอีกครั้ง")
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            }
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingStart = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }
        requestCapture()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF && pendingStart) {
            pendingStart = false
            requestCapture()
        }
    }

    private fun requestCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        try {
            val intent = if (Build.VERSION.SDK_INT >= 34) {
                // Entire screen only: sharing a single app would break the position of the translations.
                mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
            } else {
                mpm.createScreenCaptureIntent()
            }
            startActivityForResult(intent, REQ_CAPTURE)
        } catch (_: Exception) {
            toast("เปิดหน้าขออนุญาตบันทึกหน้าจอไม่ได้")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
                .putExtra(OverlayService.EXTRA_CODE, resultCode)
                .putExtra(OverlayService.EXTRA_DATA, data)
            try {
                startForegroundService(i)
                toast("เริ่มแล้ว สลับไปเปิดแอปมังงะได้เลย")
            } catch (e: Exception) {
                Prefs.setError(this, "เริ่มบริการไม่ได้: " + e.javaClass.simpleName + " " + (e.message ?: ""))
                toast("เริ่มไม่ได้ ดูรายละเอียดในบันทึกข้อผิดพลาด")
            }
            status.postDelayed({ refresh() }, 700)
        } else {
            toast("ต้องอนุญาตบันทึกหน้าจอ แอปถึงจะอ่านช่องคำพูดได้")
        }
    }

    private fun onStopPressed() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            toast("หยุดแล้ว")
        }
        status.postDelayed({ refresh() }, 500)
    }

    // ---------------- UI helpers ----------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun lp(top: Int): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        l.topMargin = dp(top)
        return l
    }

    private fun tv(s: String, size: Float, bold: Boolean, color: Int): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.setLineSpacing(0f, 1.15f)
        return v
    }

    private fun bigButton(label: String, color: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 17f
        b.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(16).toFloat()
        bg.setColor(color)
        b.background = bg
        b.setOnClickListener { onClick() }
        return b
    }

    private fun edit(value: String, hint: String): EditText {
        val e = EditText(this)
        e.setText(value)
        e.hint = hint
        e.textSize = 15f
        e.setTextColor(INK)
        return e
    }

    private fun check(label: String, value: Boolean): CheckBox {
        val c = CheckBox(this)
        c.text = label
        c.textSize = 15f
        c.setTextColor(INK)
        c.isChecked = value
        return c
    }

    private fun spinner(labels: Array<String>, selected: Int): Spinner {
        val s = Spinner(this)
        val a = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        s.adapter = a
        s.setSelection(selected)
        return s
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }
}
