package com.mangaoverlay.app

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    const val DEFAULT_MODEL = "gemini-2.5-flash"

    data class Snapshot(
        val apiKey: String,
        val model: String,
        val source: String,      // auto, ja, zh, ko, en
        val auto: Boolean,
        val sfx: Boolean,
        val honorifics: Boolean, // keep -san / oppa style forms of address
        val fontSize: Int,       // 0 small, 1 medium, 2 large
        val tone: Int,           // 0 by character, 1 casual, 2 polite
        val bubbleTheme: Int,    // 0 white, 1 dark, 2 translucent
        val tapExpand: Boolean,  // tap bubble to view large text & copy
        val glossary: String
    )

    fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(c: Context): Snapshot {
        val s = sp(c)
        return Snapshot(
            apiKey = (s.getString("apiKey", "") ?: "").trim(),
            model = s.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL,
            source = s.getString("source", "auto") ?: "auto",
            auto = s.getBoolean("auto", false),
            sfx = s.getBoolean("sfx", false),
            honorifics = s.getBoolean("honorifics", false),
            fontSize = s.getInt("fontSize", 1),
            tone = s.getInt("tone", 0),
            bubbleTheme = s.getInt("bubbleTheme", 0),
            tapExpand = s.getBoolean("tapExpand", false),
            glossary = s.getString("glossary", "") ?: ""
        )
    }

    fun save(c: Context, p: Snapshot) {
        sp(c).edit()
            .putString("apiKey", p.apiKey.trim())
            .putString("model", p.model)
            .putString("source", p.source)
            .putBoolean("auto", p.auto)
            .putBoolean("sfx", p.sfx)
            .putBoolean("honorifics", p.honorifics)
            .putInt("fontSize", p.fontSize)
            .putInt("tone", p.tone)
            .putInt("bubbleTheme", p.bubbleTheme)
            .putBoolean("tapExpand", p.tapExpand)
            .putString("glossary", p.glossary)
            .apply()
    }

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    @Synchronized
    fun addUse(c: Context) {
        val s = sp(c)
        val d = today()
        val n = if (s.getString("useDay", "") == d) s.getInt("useCount", 0) else 0
        s.edit().putString("useDay", d).putInt("useCount", n + 1).apply()
    }

    fun usesToday(c: Context): Int {
        val s = sp(c)
        return if (s.getString("useDay", "") == today()) s.getInt("useCount", 0) else 0
    }

    fun savePos(c: Context, x: Int, y: Int) {
        sp(c).edit().putInt("btnX", x).putInt("btnY", y).apply()
    }

    fun posX(c: Context): Int = sp(c).getInt("btnX", -1)
    fun posY(c: Context): Int = sp(c).getInt("btnY", -1)

    /** Uses commit() on purpose: this is also called while the app is crashing. */
    fun setError(c: Context, msg: String) {
        val stamp = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date())
        sp(c).edit().putString("lastError", "[" + stamp + "] " + msg.take(2000)).commit()
    }

    fun lastError(c: Context): String = sp(c).getString("lastError", "") ?: ""

    fun clearError(c: Context) {
        sp(c).edit().remove("lastError").apply()
    }
}
