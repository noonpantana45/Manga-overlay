package com.mangaoverlay.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.hardware.input.InputManager
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.nio.ByteBuffer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.mangaoverlay.app.STOP"
        const val ACTION_AUTO = "com.mangaoverlay.app.TOGGLE_AUTO"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 1
        private const val TW = 32
        private const val TH = 64
        private const val CHANGE_NEW = 0.08f     // screen changed enough to need a new translation
        private const val CHANGE_CLEAR = 0.05f   // screen scrolled: remove the translation
        private const val CHANGE_SAME = 0.035f   // screen identical: reuse the last translation
        private const val AUTO_MIN_GAP = 4000L

        @Volatile
        var running = false
    }

    private enum class State { IDLE, CAPTURING, TRANSLATING, SHOWING }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var frameThread: HandlerThread? = null
    @Volatile private var worker: ExecutorService = Executors.newSingleThreadExecutor()
    private lateinit var translator: Translator

    private var button: TextView? = null
    private var buttonLp: WindowManager.LayoutParams? = null
    private var layer: FrameLayout? = null
    private var menu: LinearLayout? = null
    private var cropView: View? = null
    private var detailPopup: View? = null

    private var screenW = 0
    private var screenH = 0
    private var started = false
    private var stopping = false
    private var auto = false
    private var manualCapture = false
    private var pendingCropRect: Rect? = null
    private var translateId = 0
    private var translateStart = 0L
    private var lastAutoAt = 0L
    private var captureTries = 0

    @Volatile private var state = State.IDLE
    @Volatile private var peeking = false
    @Volatile private var lastFrameTime = 0L
    @Volatile private var lastThumb: IntArray? = null
    @Volatile private var refThumb: IntArray? = null
    @Volatile private var captureHideTime = 0L
    private var lastTranslatedThumb: IntArray? = null
    private var cachedItems: List<Translator.Item>? = null
    private var cachedThumb: IntArray? = null

    private val lock = Any()
    private var frameBmp: Bitmap? = null
    private var frameW = 0
    private var frameThumb: IntArray? = null
    private var frameReady = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        auto = Prefs.load(this).auto
        styleButton()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_AUTO -> {
                if (started) toggleAuto() else stopSelf()
                return START_NOT_STICKY
            }
        }
        // Always satisfy startForegroundService(), even for a repeated start.
        startInForeground()
        if (started) return START_NOT_STICKY
        val data = if (intent != null) dataOf(intent) else null
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            begin(code, data)
        } catch (e: Throwable) {
            logError("เริ่มจับภาพหน้าจอไม่ได้", e)
            toast("เริ่มจับภาพหน้าจอไม่ได้ ดูรายละเอียดในแอป")
            stopSelf()
            return START_NOT_STICKY
        }
        started = true
        running = true
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun dataOf(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else i.getParcelableExtra(EXTRA_DATA)

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "แปลมังงะ", NotificationManager.IMPORTANCE_LOW))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), flags
        )
        val autoPi = PendingIntent.getService(
            this, 3, Intent(this, OverlayService::class.java).setAction(ACTION_AUTO), flags
        )
        val openPi = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), flags)
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("แปลมังงะกำลังทำงาน")
            .setContentText("แตะปุ่มลอยเพื่อแปล แตะค้างที่ปุ่มเพื่อเปิดเมนูด่วน")
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(Notification.Action.Builder(icon, "เปิด/ปิดออโต้", autoPi).build())
            .addAction(Notification.Action.Builder(icon, "หยุด", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun begin(code: Int, data: Intent) {
        val size = realSize()
        screenW = size.first
        screenH = size.second

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data) ?: throw IllegalStateException("ไม่ได้รับสิทธิ์บันทึกหน้าจอ")
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post {
                    if (!stopping) {
                        toast("ระบบหยุดการบันทึกหน้าจอ กดเริ่มใหม่ในแอปเพื่อใช้ต่อ")
                        stopSelf()
                    }
                }
            }
        }, main)

        val ft = HandlerThread("frames")
        ft.start()
        frameThread = ft
        val r = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        reader = r
        r.setOnImageAvailableListener({ onFrame(it) }, Handler(ft.looper))
        virtualDisplay = mp.createVirtualDisplay(
            "manga-capture", screenW, screenH, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )

        translator = Translator(applicationContext)
        auto = Prefs.load(this).auto
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        addButton()
        main.postDelayed(autoTick, 600)
    }

    private fun realSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            Pair(m.widthPixels, m.heightPixels)
        }
    }

    // ---------------- Rotation ----------------

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (started) main.postDelayed({ resizeCapture() }, 350)
    }

    private fun resizeCapture() {
        if (!started || stopping) return
        try {
            val size = realSize()
            if (size.first == screenW && size.second == screenH) return
            abortWork()
            hideMenu()
            hideCropOverlay()
            hideDetailPopup()
            removeLayer()
            peeking = false
            state = State.IDLE
            screenW = size.first
            screenH = size.second
            val ft = frameThread ?: return
            val nr = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
            nr.setOnImageAvailableListener({ onFrame(it) }, Handler(ft.looper))
            try {
                virtualDisplay?.resize(screenW, screenH, resources.displayMetrics.densityDpi)
                virtualDisplay?.surface = nr.surface
            } catch (e: Throwable) {
                nr.close()
                throw e
            }
            val old = reader
            reader = nr
            try { old?.close() } catch (_: Throwable) {}
            synchronized(lock) {
                frameBmp?.recycle()
                frameBmp = null
                frameReady = false
            }
            lastThumb = null
            lastTranslatedThumb = null
            cachedItems = null
            cachedThumb = null
            val lp = buttonLp
            val b = button
            if (lp != null && b != null) {
                lp.x = lp.x.coerceIn(0, max(0, screenW - lp.width))
                lp.y = lp.y.coerceIn(0, max(0, screenH - lp.height))
                try { wm.updateViewLayout(b, lp) } catch (_: Throwable) {}
            }
            button?.visibility = View.VISIBLE
            styleButton()
        } catch (e: Throwable) {
            logError("ปรับขนาดการจับภาพหลังหมุนจอไม่สำเร็จ", e)
        }
    }

    // ---------------- Frames ----------------

    private fun onFrame(r: ImageReader) {
        val img: Image = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val now = SystemClock.uptimeMillis()
            lastFrameTime = now
            val th = thumbOf(img)
            val st = state
            if (st == State.CAPTURING) {
                // Keep the newest frame. The last one before things settle is the clean one.
                if (now >= captureHideTime) storeFrame(img, th)
                return
            }
            lastThumb = th
            if (st == State.SHOWING && !peeking && detailPopup == null) {
                val ref = refThumb
                if (ref != null && diff(th, ref) > CHANGE_CLEAR) {
                    main.post { if (state == State.SHOWING && !peeking && detailPopup == null) clearTranslations() }
                }
            }
        } catch (e: Throwable) {
            // ignore a bad frame
        } finally {
            try { img.close() } catch (_: Throwable) {}
        }
    }

    private fun storeFrame(img: Image, th: IntArray) {
        val plane = img.planes[0]
        val ps = plane.pixelStride
        val rs = plane.rowStride
        val w = img.width
        val h = img.height
        val padW = rs / ps
        synchronized(lock) {
            var bmp = frameBmp
            if (bmp == null || bmp.isRecycled || bmp.width != padW || bmp.height != h) {
                bmp?.recycle()
                bmp = Bitmap.createBitmap(padW, h, Bitmap.Config.ARGB_8888)
                frameBmp = bmp
            }
            val target: Bitmap = bmp!!
            val buf = plane.buffer
            buf.rewind()
            val need = padW * h * 4
            if (buf.remaining() >= need) {
                target.copyPixelsFromBuffer(buf)
            } else {
                // Some devices leave the last row short: pad it.
                val tmp = ByteBuffer.allocateDirect(need)
                tmp.put(buf)
                tmp.rewind()
                target.copyPixelsFromBuffer(tmp)
            }
            frameW = w
            frameThumb = th
            frameReady = true
        }
    }

    private fun takeFrame(): Pair<Bitmap, IntArray>? {
        return synchronized(lock) {
            val b = frameBmp
            if (!frameReady || b == null || b.isRecycled) {
                null
            } else {
                val copy = Bitmap.createBitmap(b, 0, 0, min(frameW, b.width), b.height)
                frameReady = false
                Pair(copy, frameThumb ?: IntArray(TW * TH))
            }
        }
    }

    private fun thumbOf(img: Image): IntArray {
        val p = img.planes[0]
        val buf = p.buffer
        val ps = p.pixelStride
        val rs = p.rowStride
        val w = img.width
        val h = img.height
        // ตัดขอบบน 8% (นาฬิกา/แจ้งเตือน) และขอบล่าง 12% (แถบนำทาง/แบนเนอร์โฆษณา) เพื่อไม่ให้แปลซ้ำวนลูป
        val yTop = (h * 0.08f).toInt()
        val ySpan = max(1, (h * 0.80f).toInt())
        val lim = buf.limit()
        val out = IntArray(TW * TH)
        var i = 0
        for (ty in 0 until TH) {
            val y = (yTop + (ty * 2 + 1) * ySpan / (TH * 2)).coerceIn(0, h - 1)
            for (tx in 0 until TW) {
                val x = (tx * 2 + 1) * w / (TW * 2)
                val o = y * rs + x * ps
                out[i++] = if (o + 2 < lim) {
                    ((buf.get(o).toInt() and 255) * 3 + (buf.get(o + 1).toInt() and 255) * 6 + (buf.get(o + 2).toInt() and 255)) / 10
                } else 0
            }
        }
        return out
    }

    private fun diff(a: IntArray, b: IntArray): Float {
        if (a.size != b.size) return 1f
        var n = 0
        for (i in a.indices) if (abs(a[i] - b[i]) > 28) n++
        return n.toFloat() / a.size
    }

    // ---------------- Capture + translate ----------------

    private val autoTick = object : Runnable {
        override fun run() {
            try {
                val now = SystemClock.uptimeMillis()
                if (state == State.TRANSLATING && now - translateStart > 240_000L) {
                    cancelTranslation(false)
                } else if (auto && state == State.IDLE && cropView == null && now - lastAutoAt >= AUTO_MIN_GAP) {
                    val t = lastThumb
                    if (t != null && now - lastFrameTime >= 900) {
                        val prev = lastTranslatedThumb
                        if (prev == null || diff(t, prev) > CHANGE_NEW) {
                            lastAutoAt = now
                            startCapture(false, null)
                        }
                    }
                }
            } catch (e: Throwable) {
                logError("ตัวตรวจจับหน้าจอผิดพลาด", e)
            }
            main.postDelayed(this, 300)
        }
    }

    private fun startCapture(manual: Boolean, cropRect: Rect? = null) {
        if (state != State.IDLE || projection == null) return
        manualCapture = manual
        pendingCropRect = cropRect
        hideMenu()
        hideDetailPopup()

        // Same screen as the last translation: show it again without spending quota (only for full screen).
        val ci = cachedItems
        val ct = cachedThumb
        val lt = lastThumb
        if (manual && cropRect == null && ci != null && ct != null && lt != null &&
            SystemClock.uptimeMillis() - lastFrameTime > 250 && diff(lt, ct) < CHANGE_SAME
        ) {
            showLayer(ci)
            state = State.SHOWING
            scheduleRef()
            styleButton()
            return
        }

        // The screen may have rotated without us hearing about it.
        val size = realSize()
        if (size.first != screenW || size.second != screenH) {
            resizeCapture()
            if (manual) toast("เพิ่งหมุนจอ แตะแปลอีกครั้ง")
            return
        }

        state = State.CAPTURING
        synchronized(lock) { frameReady = false }
        captureHideTime = SystemClock.uptimeMillis()
        button?.visibility = View.INVISIBLE   // hide our own button so it is not in the screenshot
        captureTries = 0
        main.postDelayed(captureCheck, 380)
    }

    private val captureCheck = object : Runnable {
        override fun run() {
            if (state != State.CAPTURING) return
            try {
                val fr = takeFrame()
                if (fr == null) {
                    captureTries++
                    if (captureTries < 6) {
                        main.postDelayed(this, 250)
                        return
                    }
                    state = State.IDLE
                    button?.visibility = View.VISIBLE
                    styleButton()
                    if (manualCapture) toast("จับภาพหน้าจอไม่ได้ ลองแตะอีกครั้ง")
                    return
                }
                button?.visibility = View.VISIBLE
                lastTranslatedThumb = fr.second
                lastThumb = fr.second
                state = State.TRANSLATING
                translateStart = SystemClock.uptimeMillis()
                styleButton()
                val snap = Prefs.load(this@OverlayService)
                val id = ++translateId
                val bmp = fr.first
                val crop = pendingCropRect
                pendingCropRect = null
                try {
                    worker.execute { runTranslate(bmp, snap, id, crop) }
                } catch (e: Throwable) {
                    bmp.recycle()
                    state = State.IDLE
                    styleButton()
                    logError("ส่งงานแปลไม่สำเร็จ", e)
                }
            } catch (e: Throwable) {
                state = State.IDLE
                button?.visibility = View.VISIBLE
                styleButton()
                logError("จับภาพหน้าจอผิดพลาด", e)
            }
        }
    }

    private fun runTranslate(bmp: Bitmap, snap: Prefs.Snapshot, id: Int, crop: Rect?) {
        var res: Translator.Result? = null
        var err: String? = null
        var subBmp: Bitmap? = null
        try {
            if (crop != null) {
                val cl = crop.left.coerceIn(0, max(0, bmp.width - 10))
                val ct = crop.top.coerceIn(0, max(0, bmp.height - 10))
                val cw = crop.width().coerceIn(10, bmp.width - cl)
                val ch = crop.height().coerceIn(10, bmp.height - ct)
                subBmp = Bitmap.createBitmap(bmp, cl, ct, cw, ch)
                val rawRes = translator.run(subBmp, snap)
                val shifted = rawRes.items.map { item ->
                    val nr = Rect(
                        item.rect.left + cl,
                        item.rect.top + ct,
                        item.rect.right + cl,
                        item.rect.bottom + ct
                    )
                    item.copy(rect = nr)
                }
                res = Translator.Result(shifted, rawRes.notice)
            } else {
                res = translator.run(bmp, snap)
            }
        } catch (e: Throwable) {
            err = e.javaClass.simpleName + (if (e.message != null) ": " + e.message!!.take(160) else "")
        }
        try { subBmp?.recycle() } catch (_: Throwable) {}
        try { bmp.recycle() } catch (_: Throwable) {}
        val r = res
        val e = err
        main.post { onResult(id, r, e) }
    }

    private fun onResult(id: Int, res: Translator.Result?, err: String?) {
        if (!running || id != translateId || state != State.TRANSLATING) return
        try {
            if (res == null) {
                state = State.IDLE
                styleButton()
                Prefs.setError(this, "แปลไม่สำเร็จ: " + (err ?: "ไม่ทราบสาเหตุ"))
                toast("แปลไม่สำเร็จ ดูรายละเอียดในแอป (โหมดสำรองต้องต่อเน็ตครั้งแรกเพื่อโหลดโมเดลภาษา)")
                return
            }
            res.notice?.let { toast(it) }
            // If the reader scrolled while we were translating, the boxes no longer match.
            val now = lastThumb
            val then = lastTranslatedThumb
            if (now != null && then != null && diff(now, then) > CHANGE_NEW) {
                state = State.IDLE
                lastTranslatedThumb = null
                styleButton()
                if (manualCapture) toast("หน้าจอเลื่อนไปแล้ว แตะแปลอีกครั้ง")
                return
            }
            if (res.items.isEmpty()) {
                state = State.IDLE
                styleButton()
                if (manualCapture) toast("ไม่พบข้อความในบริเวณที่เลือก")
                return
            }
            cachedItems = res.items
            cachedThumb = lastTranslatedThumb
            showLayer(res.items)
            state = State.SHOWING
            scheduleRef()
            styleButton()
        } catch (e: Throwable) {
            state = State.IDLE
            styleButton()
            logError("แสดงคำแปลไม่สำเร็จ", e)
        }
    }

    private fun abortWork() {
        translateId++
        main.removeCallbacks(captureCheck)
        main.removeCallbacks(setRef)
        if (::translator.isInitialized) translator.cancel()
        val old = worker
        worker = Executors.newSingleThreadExecutor()
        try { old.shutdownNow() } catch (_: Throwable) {}
        button?.visibility = View.VISIBLE
    }

    private fun cancelTranslation(announce: Boolean) {
        abortWork()
        state = State.IDLE
        styleButton()
        if (announce) toast("ยกเลิกการแปลแล้ว")
    }

    // ---------------- Crop-to-Translate Overlay ----------------

    private fun startCropSelector() {
        hideMenu()
        hideDetailPopup()
        if (state == State.SHOWING) clearTranslations()
        if (state != State.IDLE) return
        hideCropOverlay()

        val v = object : View(this) {
            private var sx = 0f
            private var sy = 0f
            private var ex = 0f
            private var ey = 0f
            private var dragging = false
            private val dimPaint = Paint().apply { color = 0x66000000 }
            private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFF0F7B6C.toInt()
                style = Paint.Style.STROKE
                strokeWidth = dp(3).toFloat()
            }
            private val fillPaint = Paint().apply {
                color = 0x220F7B6C
                style = Paint.Style.FILL
            }
            private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 16f, resources.displayMetrics)
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.CENTER
            }

            override fun onDraw(c: Canvas) {
                super.onDraw(c)
                c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)
                c.drawText(
                    "ลากนิ้วคลุมช่องคำพูดที่ต้องการแปล (แตะ 1 ครั้งเพื่อยกเลิก)",
                    width / 2f,
                    dp(72).toFloat(),
                    textPaint
                )
                if (dragging) {
                    val r = RectF(min(sx, ex), min(sy, ey), max(sx, ex), max(sy, ey))
                    c.drawRect(r, fillPaint)
                    c.drawRect(r, borderPaint)
                }
            }

            override fun onTouchEvent(event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = event.x
                        sy = event.y
                        ex = sx
                        ey = sy
                        dragging = true
                        invalidate()
                    }
                    MotionEvent.ACTION_MOVE -> {
                        ex = event.x
                        ey = event.y
                        invalidate()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        dragging = false
                        val loc = IntArray(2)
                        getLocationOnScreen(loc)
                        val l = (min(sx, ex) + loc[0]).toInt()
                        val t = (min(sy, ey) + loc[1]).toInt()
                        val r = (max(sx, ex) + loc[0]).toInt()
                        val b = (max(sy, ey) + loc[1]).toInt()
                        hideCropOverlay()
                        if (r - l >= dp(36) && b - t >= dp(28)) {
                            startCapture(true, Rect(l, t, r, b))
                        } else {
                            toast("ยกเลิกโหมดแปลเฉพาะจุด")
                        }
                    }
                }
                return true
            }
        }

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        try {
            wm.addView(v, lp)
            cropView = v
        } catch (e: Throwable) {
            logError("เปิดโหมดลากกรอบไม่ได้", e)
        }
    }

    private fun hideCropOverlay() {
        val v = cropView ?: return
        cropView = null
        try { wm.removeView(v) } catch (_: Throwable) {}
    }

    // ---------------- Translation layer ----------------

    private val setRef = Runnable {
        if (state == State.SHOWING && !peeking) refThumb = lastThumb
    }

    private fun scheduleRef() {
        refThumb = null
        main.removeCallbacks(setRef)
        main.postDelayed(setRef, 700)
    }

    private fun showLayer(items: List<Translator.Item>) {
        removeLayer()
        val snap = Prefs.load(this)
        val l = FrameLayout(this)
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!snap.tapExpand) {
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        } else {
            l.setOnClickListener { clearTranslations() }
        }
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        if (Build.VERSION.SDK_INT >= 31 && !snap.tapExpand) {
            // Android 12+ lets touches pass through another app's overlay only when it is at most
            // this opaque, so the reader can keep scrolling underneath.
            val im = getSystemService(InputManager::class.java)
            lp.alpha = im?.maximumObscuringOpacityForTouch ?: 0.8f
        }
        try {
            wm.addView(l, lp)
        } catch (e: Throwable) {
            toast("แสดงคำแปลไม่ได้ ตรวจสิทธิ์แสดงทับแอปอื่น")
            logError("แสดงคำแปลไม่ได้", e)
            return
        }
        layer = l
        bringButtonToFront()
        l.post { if (layer === l) placeBubbles(l, items, snap) }
    }

    private fun placeBubbles(l: FrameLayout, items: List<Translator.Item>, snap: Prefs.Snapshot) {
        try {
            val loc = IntArray(2)
            l.getLocationOnScreen(loc)
            val lw = if (l.width > 0) l.width else screenW
            val lh = if (l.height > 0) l.height else screenH
            val maxSp = when (snap.fontSize) {
                0 -> 15
                2 -> 22
                else -> 18
            }
            val minW = dp(46)
            val minH = dp(24)
            val grow = dp(2)
            val padH = dp(4)
            val padV = dp(2)
            val face = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            val measure = TextPaint(Paint.ANTI_ALIAS_FLAG)
            measure.typeface = face
            measure.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 10f, resources.displayMetrics)
            val placedRects = ArrayList<Rect>()

            for (item in items) {
                val origX = (item.rect.left - loc[0] - grow).coerceIn(0, max(0, lw - minW))
                val origY = (item.rect.top - loc[1] - grow).coerceIn(0, max(0, lh - minH))
                val origW = (item.rect.width() + grow * 2).coerceIn(minW, lw)
                val origH = (item.rect.height() + grow * 2).coerceIn(minH, lh)

                var x = origX
                var y = origY
                val w = origW
                var h = origH

                // ขยายกล่องเฉพาะเท่าที่ไม่เกิน 1.35 เท่าของบอลลูนเดิม และไม่ชนกับกล่องข้างเคียง
                val innerW = max(dp(28), w - padH * 2)
                val sl = StaticLayout.Builder.obtain(item.text, 0, item.text.length, measure, innerW)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setIncludePad(false)
                    .build()
                val need = (sl.height * 1.08f).toInt() + padV * 2
                if (need > h) {
                    val maxAllowedH = min((origH * 1.35f).toInt(), (lh * 0.28f).toInt())
                    val nh = min(need, max(h, maxAllowedH))
                    val ny = (y - (nh - h) / 2).coerceIn(0, max(0, lh - nh))
                    val candidate = Rect(x, ny, x + w, ny + nh)
                    if (placedRects.none { Rect.intersects(it, candidate) }) {
                        y = ny
                        h = nh
                    }
                }
                x = x.coerceIn(0, max(0, lw - w))
                y = y.coerceIn(0, max(0, lh - h))
                placedRects.add(Rect(x, y, x + w, y + h))

                val tv = TextView(this)
                tv.text = item.text
                val isDark = snap.bubbleTheme == 1
                val isTrans = snap.bubbleTheme == 2
                val textColor = when {
                    isDark && item.kind == "sfx" -> 0xFFFFE082.toInt()
                    isDark -> 0xFFF5F7FA.toInt()
                    else -> 0xFF111111.toInt()
                }
                val bgColor = when {
                    isDark && item.kind == "sfx" -> 0xF23B2F12.toInt()
                    isDark -> 0xF2181A20.toInt()
                    isTrans && item.kind == "sfx" -> 0xD6FFF0A0.toInt()
                    isTrans -> 0xD8FFFFFF.toInt()
                    item.kind == "sfx" -> 0xFFFFF0A0.toInt()
                    else -> Color.WHITE
                }
                val strokeColor = if (isDark) 0xCC8A94A6.toInt() else 0xCC222222.toInt()

                tv.setTextColor(textColor)
                tv.gravity = Gravity.CENTER
                tv.typeface = face
                tv.includeFontPadding = false
                tv.setPadding(padH, padV, padH, padV)
                val bg = GradientDrawable()
                bg.setColor(bgColor)
                bg.cornerRadius = dp(if (item.kind == "caption") 4 else 14).toFloat()
                if (item.kind == "thought") {
                    bg.setStroke(dp(1), strokeColor, dp(4).toFloat(), dp(3).toFloat())
                } else {
                    bg.setStroke(dp(1), strokeColor)
                }
                tv.background = bg
                tv.setAutoSizeTextTypeUniformWithConfiguration(8, maxSp, 1, TypedValue.COMPLEX_UNIT_SP)
                if (snap.tapExpand) {
                    tv.setOnClickListener { showDetailPopup(item) }
                }
                val lpb = FrameLayout.LayoutParams(w, h)
                lpb.leftMargin = x
                lpb.topMargin = y
                l.addView(tv, lpb)
            }
        } catch (e: Throwable) {
            logError("จัดวางคำแปลไม่สำเร็จ", e)
        }
    }

    // ---------------- Tap Bubble to Expand & Copy Popup ----------------

    private fun showDetailPopup(item: Translator.Item) {
        hideDetailPopup()
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(18), dp(16), dp(18), dp(16))
        val bg = GradientDrawable()
        bg.setColor(0xFA1E2430.toInt())
        bg.cornerRadius = dp(18).toFloat()
        bg.setStroke(dp(1), 0xFF4A5568.toInt())
        card.background = bg

        val title = TextView(this)
        title.text = "คำแปลขยาย"
        title.textSize = 13f
        title.setTextColor(0xFF94A3B8.toInt())
        card.addView(title)

        val trText = TextView(this)
        trText.text = item.text
        trText.textSize = 19f
        trText.setTextColor(Color.WHITE)
        trText.typeface = Typeface.DEFAULT_BOLD
        trText.setPadding(0, dp(6), 0, dp(10))
        card.addView(trText)

        if (item.src.isNotBlank()) {
            val srcTitle = TextView(this)
            srcTitle.text = "ข้อความต้นฉบับ:"
            srcTitle.textSize = 12f
            srcTitle.setTextColor(0xFF94A3B8.toInt())
            card.addView(srcTitle)

            val srcText = TextView(this)
            srcText.text = item.src
            srcText.textSize = 15f
            srcText.setTextColor(0xFFE2E8F0.toInt())
            srcText.setPadding(0, dp(4), 0, dp(12))
            card.addView(srcText)
        }

        val btnRow = LinearLayout(this)
        btnRow.orientation = LinearLayout.HORIZONTAL
        btnRow.gravity = Gravity.END

        fun smallBtn(label: String, bgHex: Int, onClick: () -> Unit): TextView {
            val b = TextView(this)
            b.text = label
            b.textSize = 13f
            b.setTextColor(Color.WHITE)
            b.typeface = Typeface.DEFAULT_BOLD
            b.setPadding(dp(12), dp(8), dp(12), dp(8))
            val bbg = GradientDrawable()
            bbg.setColor(bgHex)
            bbg.cornerRadius = dp(10).toFloat()
            b.background = bbg
            val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            blp.leftMargin = dp(6)
            b.layoutParams = blp
            b.setOnClickListener { onClick() }
            return b
        }

        val cm = getSystemService(ClipboardManager::class.java)
        btnRow.addView(smallBtn("คัดลอกคำแปล", 0xFF0F7B6C.toInt()) {
            cm.setPrimaryClip(ClipData.newPlainText("translation", item.text))
            toast("คัดลอกคำแปลแล้ว")
            hideDetailPopup()
        })
        if (item.src.isNotBlank()) {
            btnRow.addView(smallBtn("คัดลอกต้นฉบับ", 0xFF3D4A63.toInt()) {
                cm.setPrimaryClip(ClipData.newPlainText("source", item.src))
                toast("คัดลอกข้อความต้นฉบับแล้ว")
                hideDetailPopup()
            })
        }
        btnRow.addView(smallBtn("ปิด", 0xFF64748B.toInt()) { hideDetailPopup() })
        card.addView(btnRow)

        val wrapper = FrameLayout(this)
        wrapper.setBackgroundColor(0x66000000)
        wrapper.setOnClickListener { hideDetailPopup() }
        val clp = FrameLayout.LayoutParams(
            min(screenW - dp(32), dp(360)),
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        )
        card.setOnClickListener { /* consume click inside card */ }
        wrapper.addView(card, clp)

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(wrapper, lp)
            detailPopup = wrapper
            bringButtonToFront()
        } catch (e: Throwable) {
            logError("เปิดหน้าต่างขยายคำแปลไม่ได้", e)
        }
    }

    private fun hideDetailPopup() {
        val p = detailPopup ?: return
        detailPopup = null
        try { wm.removeView(p) } catch (_: Throwable) {}
    }

    private fun removeLayer() {
        hideDetailPopup()
        val l = layer ?: return
        layer = null
        try { wm.removeView(l) } catch (_: Throwable) {}
    }

    private fun clearTranslations() {
        main.removeCallbacks(setRef)
        removeLayer()
        peeking = false
        state = State.IDLE
        styleButton()
    }

    // ---------------- Floating button ----------------

    private fun addButton() {
        val size = dp(58)
        val b = TextView(this)
        b.gravity = Gravity.CENTER
        b.setTextColor(Color.WHITE)
        b.textSize = 14f
        b.typeface = Typeface.DEFAULT_BOLD
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val sx = Prefs.posX(this)
        val sy = Prefs.posY(this)
        lp.x = if (sx >= 0) sx.coerceIn(0, max(0, screenW - size)) else screenW - size - dp(10)
        lp.y = if (sy >= 0) sy.coerceIn(0, max(0, screenH - size)) else screenH * 2 / 5
        b.setOnTouchListener(touchListener)
        wm.addView(b, lp)
        button = b
        buttonLp = lp
        styleButton()
    }

    private fun bringButtonToFront() {
        val b = button ?: return
        val lp = buttonLp ?: return
        try {
            wm.removeView(b)
            wm.addView(b, lp)
        } catch (_: Throwable) {}
    }

    private fun styleButton() {
        val b = button ?: return
        val fallback = ::translator.isInitialized && translator.usingFallback()
        val look = when (state) {
            State.CAPTURING, State.TRANSLATING -> Pair("…", 0xFFE0921A.toInt())
            State.SHOWING -> Pair("ซ่อน", 0xFF2E3445.toInt())
            State.IDLE -> Pair(
                if (auto) "AUTO" else "แปล",
                if (fallback) 0xFF6B5BD6.toInt() else 0xFF0F7B6C.toInt()
            )
        }
        b.text = look.first
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(look.second)
        bg.setStroke(dp(2), Color.WHITE)
        b.background = bg
    }

    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false
    private var longPressed = false
    private var peeked = false

    private val peekRunnable = Runnable {
        when (state) {
            State.SHOWING -> {
                peeked = true
                peeking = true
                longPressed = true
                layer?.visibility = View.INVISIBLE
            }
            State.IDLE -> {
                longPressed = true
                showMenu()
            }
            else -> {}
        }
    }

    private val touchListener = View.OnTouchListener { v, e ->
        val lp = buttonLp ?: return@OnTouchListener false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                startX = lp.x
                startY = lp.y
                moved = false
                longPressed = false
                peeked = false
                main.postDelayed(peekRunnable, 400)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!moved && (abs(dx) > dp(8) || abs(dy) > dp(8))) {
                    moved = true
                    main.removeCallbacks(peekRunnable)
                    if (peeked) endPeek()
                }
                if (moved) {
                    lp.x = (startX + dx.toInt()).coerceIn(0, max(0, screenW - lp.width))
                    lp.y = (startY + dy.toInt()).coerceIn(0, max(0, screenH - lp.height))
                    try { wm.updateViewLayout(v, lp) } catch (_: Throwable) {}
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                main.removeCallbacks(peekRunnable)
                if (peeked) {
                    endPeek()
                } else if (moved) {
                    Prefs.savePos(this, lp.x, lp.y)
                } else if (e.actionMasked == MotionEvent.ACTION_UP && !longPressed) {
                    try { onTap() } catch (t: Throwable) { logError("แตะปุ่มแล้วผิดพลาด", t) }
                }
            }
        }
        true
    }

    private fun endPeek() {
        peeked = false
        if (!peeking) return
        peeking = false
        layer?.visibility = View.VISIBLE
        scheduleRef()
    }

    private fun onTap() {
        when (state) {
            State.SHOWING -> clearTranslations()
            State.IDLE -> startCapture(true, null)
            State.CAPTURING, State.TRANSLATING -> cancelTranslation(true)
        }
    }

    // ---------------- Small menu (hold the button) ----------------

    private val hideMenuRunnable = Runnable { hideMenu() }

    private fun showMenu() {
        hideMenu()
        val snap = Prefs.load(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(menuItem("แปลเฉพาะจุด (ลากกรอบ)") {
            hideMenu()
            startCropSelector()
        })
        col.addView(menuItem(if (snap.tapExpand) "ปิดแตะกล่องเพื่อขยาย" else "เปิดแตะกล่องเพื่อขยาย") {
            hideMenu()
            val cur = Prefs.load(this)
            Prefs.save(this, cur.copy(tapExpand = !cur.tapExpand))
            toast(if (!cur.tapExpand) "เปิดโหมดแตะกล่องคำแปลเพื่อดูข้อความขยายและคัดลอก" else "ปิดโหมดแตะกล่องเพื่อขยาย (เลื่อนจอทะลุกล่องได้)")
        })
        col.addView(menuItem(if (auto) "ปิดแปลอัตโนมัติ" else "เปิดแปลอัตโนมัติ") {
            hideMenu()
            toggleAuto()
        })
        col.addView(menuItem("หยุดการทำงาน") {
            hideMenu()
            stopSelf()
        })
        val mw = dp(176)
        val mh = dp(44) * 4 + dp(12)
        val lp = WindowManager.LayoutParams(
            mw, mh,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val bl = buttonLp
        val bx = bl?.x ?: 0
        val by = bl?.y ?: 0
        val bw = bl?.width ?: dp(58)
        lp.x = if (bx > screenW / 2) bx - mw - dp(6) else bx + bw + dp(6)
        lp.x = lp.x.coerceIn(0, max(0, screenW - mw))
        lp.y = by.coerceIn(0, max(0, screenH - mh))
        try {
            wm.addView(col, lp)
            menu = col
            main.postDelayed(hideMenuRunnable, 6000)
        } catch (e: Throwable) {
            logError("เปิดเมนูไม่ได้", e)
        }
    }

    private fun menuItem(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 13.5f
        t.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.setColor(0xF02E3445.toInt())
        bg.cornerRadius = dp(12).toFloat()
        t.background = bg
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44))
        lp.bottomMargin = dp(3)
        lp.topMargin = dp(3)
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    private fun hideMenu() {
        main.removeCallbacks(hideMenuRunnable)
        val m = menu ?: return
        menu = null
        try { wm.removeView(m) } catch (_: Throwable) {}
    }

    private fun toggleAuto() {
        val s = Prefs.load(this)
        Prefs.save(this, s.copy(auto = !s.auto))
        toast(if (!s.auto) "เปิดแปลอัตโนมัติ ภาพหน้าจอจะถูกส่งไปแปลทุกครั้งที่หยุดเลื่อน" else "ปิดแปลอัตโนมัติ")
    }

    // ---------------- Helpers ----------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(msg: String) {
        try {
            Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
        } catch (_: Throwable) {
        }
    }

    private fun logError(where: String, e: Throwable) {
        try {
            Prefs.setError(this, where + ": " + e.javaClass.simpleName + " " + (e.message ?: ""))
        } catch (_: Throwable) {
        }
    }

    override fun onDestroy() {
        stopping = true
        running = false
        started = false
        main.removeCallbacksAndMessages(null)
        try { Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener) } catch (_: Throwable) {}
        if (::translator.isInitialized) translator.cancel()
        try { worker.shutdownNow() } catch (_: Throwable) {}
        hideMenu()
        hideCropOverlay()
        hideDetailPopup()
        removeLayer()
        button?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        button = null
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        virtualDisplay = null
        try { reader?.close() } catch (_: Throwable) {}
        reader = null
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        frameThread?.quitSafely()
        if (::translator.isInitialized) translator.close()
        synchronized(lock) {
            frameBmp?.recycle()
            frameBmp = null
        }
        super.onDestroy()
    }
}
