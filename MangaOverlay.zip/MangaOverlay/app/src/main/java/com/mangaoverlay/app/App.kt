package com.mangaoverlay.app

import android.app.Application
import android.util.Log

/** Saves the reason of a crash so it can be read (and copied) from the main screen next time. */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                Prefs.setError(this, "แอปค้างหรือปิดตัว: " + Log.getStackTraceString(e).take(1800))
            } catch (_: Throwable) {
            }
            if (old != null) old.uncaughtException(t, e)
        }
    }
}
