package com.mangaoverlay.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Base64
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CancellationException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import com.google.mlkit.nl.translate.Translator as MlTranslator

/**
 * Turns a screenshot into a list of translated speech bubbles.
 *
 * Main path: Gemini (free tier) reads the whole image and translates with context.
 * If one Gemini model runs out of free quota the next model is tried; if all of them
 * fail the on-device ML Kit OCR + translation is used so the button never goes dead.
 *
 * run() and cancel() may be called from different threads. Everything else is private.
 */
class Translator(private val ctx: Context) {

    data class Item(val rect: Rect, val text: String, val src: String, val kind: String)
    data class Result(val items: List<Item>, val notice: String?)

    private class HttpError(val code: Int, val body: String) : Exception("HTTP $code")
    private class Blocked(message: String) : Exception(message)

    private val pausedUntil = ConcurrentHashMap<String, Long>()
    private val history = ArrayDeque<String>()
    private val recognizers = HashMap<String, TextRecognizer>()
    private val mlTranslators = HashMap<String, MlTranslator>()

    @Volatile private var gen = 0
    @Volatile private var conn: HttpURLConnection? = null
    @Volatile private var thinkingOff = true
    @Volatile private var badKey: String? = null
    @Volatile private var lastNotice: String? = null

    // ---------------- Public ----------------

    /** True when the next translation will use the weaker on-device mode. */
    fun usingFallback(): Boolean {
        val p = Prefs.load(ctx)
        if (p.apiKey.isEmpty() || p.apiKey == badKey) return true
        val now = System.currentTimeMillis()
        return candidates(p).all { (pausedUntil[it] ?: 0L) > now }
    }

    /** Aborts the translation that is running now (from another thread). */
    fun cancel() {
        gen++
        try { conn?.disconnect() } catch (_: Exception) {}
    }

    fun run(bmp: Bitmap, p: Prefs.Snapshot): Result {
        val g = gen
        var why: String? = null
        val key = p.apiKey.trim()

        if (key.isEmpty()) {
            why = "ยังไม่ได้ใส่ Gemini API key จึงใช้โหมดสำรองในเครื่อง"
        } else if (key == badKey) {
            why = "API key ใช้ไม่ได้ ตรวจสอบในแอป ตอนนี้ใช้โหมดสำรองในเครื่อง"
        } else {
            val began = System.currentTimeMillis()
            val prompt = prompt(p)
            val b64 = encode(bmp)
            for (model in candidates(p)) {
                ensureAlive(g)
                val now = System.currentTimeMillis()
                if ((pausedUntil[model] ?: 0L) > now) continue
                if (now - began > 80_000L) {
                    why = "Gemini ตอบช้าเกินไป ใช้โหมดสำรองในเครื่องแทน"
                    break
                }
                try {
                    val items = askGemini(model, prompt, b64, key, bmp.width, bmp.height, g)
                    Prefs.addUse(ctx)
                    remember(items)
                    lastNotice = null
                    return Result(items, null)
                } catch (e: HttpError) {
                    val msg = errorMessage(e.body)
                    when {
                        e.code == 429 -> {
                            pausedUntil[model] = now + quotaPause(e.body)
                            why = "โควตาฟรีของ Gemini หมดชั่วคราว ใช้โหมดสำรองในเครื่องไปก่อน"
                        }
                        e.code == 404 -> {
                            pausedUntil[model] = now + 3_600_000L
                            why = "ไม่พบโมเดล " + model + " ลองแก้ชื่อโมเดลในแอป"
                        }
                        e.code == 401 || e.code == 403 || (e.code == 400 && msg.contains("API key", ignoreCase = true)) -> {
                            badKey = key
                            why = "API key ใช้ไม่ได้ (" + e.code + ") ตรวจสอบในแอป ตอนนี้ใช้โหมดสำรองในเครื่อง"
                            break
                        }
                        else -> {
                            if (e.code >= 500) pausedUntil[model] = now + 30_000L
                            why = "Gemini ขัดข้อง (" + e.code + ") ใช้โหมดสำรองในเครื่องแทน"
                        }
                    }
                } catch (e: Blocked) {
                    why = e.message
                    break
                } catch (e: IOException) {
                    ensureAlive(g)
                    why = "เชื่อมต่อ Gemini ไม่ได้ ใช้โหมดสำรองในเครื่องแทน"
                    break
                } catch (e: JSONException) {
                    why = "อ่านคำตอบจาก Gemini ไม่ได้ ใช้โหมดสำรองในเครื่องแทน"
                }
            }
            if (why == null) why = "โควตาฟรีของ Gemini หมดชั่วคราว ใช้โหมดสำรองในเครื่องไปก่อน"
        }

        ensureAlive(g)
        val items = mlkit(bmp, p, g)
        val notice = if (why != null && why != lastNotice) why else null
        lastNotice = why
        return Result(items, notice)
    }

    fun close() {
        try { recognizers.values.forEach { it.close() } } catch (_: Exception) {}
        try { mlTranslators.values.forEach { it.close() } } catch (_: Exception) {}
    }

    // ---------------- Models ----------------

    private fun candidates(p: Prefs.Snapshot): List<String> {
        val first = p.model.trim().removePrefix("models/").ifEmpty { Prefs.DEFAULT_MODEL }
        return listOf(first, "gemini-2.5-flash", "gemini-flash-latest", "gemini-flash-lite-latest").distinct()
    }

    private fun ensureAlive(g: Int) {
        if (g != gen || Thread.currentThread().isInterrupted) throw CancellationException()
    }

    private fun sleepAlive(ms: Long, g: Int) {
        Thread.sleep(ms)
        ensureAlive(g)
    }

    private fun quotaPause(body: String): Long {
        val m = Regex("\"retryDelay\"\\s*:\\s*\"(\\d+(?:\\.\\d+)?)s\"").find(body)
        var secs = m?.groupValues?.get(1)?.toDoubleOrNull()?.toLong() ?: 60L
        if (body.contains("PerDay", ignoreCase = true)) secs = maxOf(secs, 30 * 60L)
        return minOf(maxOf(secs, 10L), 6 * 3600L) * 1000L
    }

    // ---------------- Gemini ----------------

    private fun askGemini(model: String, prompt: String, b64: String, key: String, w: Int, h: Int, g: Int): List<Item> {
        var attempt = 0
        while (true) {
            ensureAlive(g)
            val body = buildBody(prompt, b64, thinkingOff)
            try {
                val raw = post(model, body, key)
                return parse(raw, w, h)
            } catch (e: HttpError) {
                if (e.code == 400 && thinkingOff && e.body.contains("think", ignoreCase = true)) {
                    thinkingOff = false // this model does not accept the setting: retry without it
                    continue
                }
                if (e.code >= 500 && attempt == 0) {
                    attempt++
                    sleepAlive(1500, g)
                    continue
                }
                throw e
            } catch (e: IOException) {
                ensureAlive(g)
                if (attempt == 0) {
                    attempt++
                    sleepAlive(1000, g)
                    continue
                }
                throw e
            }
        }
    }

    private fun post(model: String, body: ByteArray, key: String): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent")
        val c = url.openConnection() as HttpURLConnection
        conn = c
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setFixedLengthStreamingMode(body.size)
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw HttpError(code, text)
            return text
        } finally {
            try { c.disconnect() } catch (_: Exception) {}
            if (conn === c) conn = null
        }
    }

    private fun buildBody(prompt: String, b64: String, noThinking: Boolean): ByteArray {
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
        val gc = JSONObject()
            .put("responseMimeType", "application/json")
            .put("temperature", 0.4)
            .put("maxOutputTokens", 8192)
        if (noThinking) gc.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        // Comics often contain fights and mature scenes; do not let the default filters drop whole pages.
        val safety = JSONArray()
        for (cat in arrayOf(
            "HARM_CATEGORY_HARASSMENT", "HARM_CATEGORY_HATE_SPEECH",
            "HARM_CATEGORY_SEXUALLY_EXPLICIT", "HARM_CATEGORY_DANGEROUS_CONTENT"
        )) {
            safety.put(JSONObject().put("category", cat).put("threshold", "BLOCK_NONE"))
        }
        return JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", gc)
            .put("safetySettings", safety)
            .toString().toByteArray(Charsets.UTF_8)
    }

    private fun encode(bmp: Bitmap): String {
        val maxSide = 2000f
        val scale = minOf(1f, maxSide / maxOf(bmp.width, bmp.height))
        val src = if (scale < 1f) {
            Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
        } else bmp
        val out = ByteArrayOutputStream()
        src.compress(Bitmap.CompressFormat.JPEG, 85, out)
        if (src !== bmp) src.recycle()
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun errorMessage(text: String): String = try {
        JSONObject(text).getJSONObject("error").optString("message")
    } catch (e: Exception) {
        text.take(200)
    }

    private fun parse(raw: String, w: Int, h: Int): List<Item> {
        val root = JSONObject(raw)
        val block = root.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
        if (block.isNotEmpty()) throw Blocked("Gemini ปฏิเสธภาพนี้ ($block) ใช้โหมดสำรองในเครื่องแทน")

        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) throw Blocked("Gemini ไม่ตอบกลับ ใช้โหมดสำรองในเครื่องแทน")
        val c0 = cands.getJSONObject(0)
        val parts = c0.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val pt = parts.optJSONObject(i) ?: continue
                if (pt.optBoolean("thought", false)) continue
                sb.append(pt.optString("text", ""))
            }
        }
        var s = sb.toString().trim()
        if (s.isEmpty()) {
            val fr = c0.optString("finishReason", "")
            if (fr == "SAFETY" || fr == "PROHIBITED_CONTENT" || fr == "BLOCKLIST" || fr == "SPII" || fr == "IMAGE_SAFETY") {
                throw Blocked("Gemini ปฏิเสธหน้านี้ ($fr) ใช้โหมดสำรองในเครื่องแทน")
            }
            throw JSONException("empty response")
        }
        s = s.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val arr = toArray(s)

        val out = ArrayList<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val tr = o.optString("tr", "").trim()
            if (tr.isEmpty()) continue
            val box = o.optJSONArray("box") ?: o.optJSONArray("box_2d") ?: continue
            if (box.length() < 4) continue
            var y0 = box.optDouble(0)
            var x0 = box.optDouble(1)
            var y1 = box.optDouble(2)
            var x1 = box.optDouble(3)
            if (y0.isNaN() || x0.isNaN() || y1.isNaN() || x1.isNaN()) continue
            y0 = y0.coerceIn(0.0, 1000.0)
            x0 = x0.coerceIn(0.0, 1000.0)
            y1 = y1.coerceIn(0.0, 1000.0)
            x1 = x1.coerceIn(0.0, 1000.0)
            if (y1 < y0) { val t = y0; y0 = y1; y1 = t }
            if (x1 < x0) { val t = x0; x0 = x1; x1 = t }
            if (y1 - y0 < 5.0 || x1 - x0 < 5.0) continue
            val rect = Rect(
                (x0 / 1000.0 * w).toInt(), (y0 / 1000.0 * h).toInt(),
                (x1 / 1000.0 * w).toInt(), (y1 / 1000.0 * h).toInt()
            )
            val kind = o.optString("kind", "speech").lowercase()
            out.add(Item(rect, tr, o.optString("src", ""), if (kind == "thought" || kind == "caption" || kind == "sfx") kind else "speech"))
        }
        return out
    }

    private fun toArray(s: String): JSONArray {
        try {
            return if (s.startsWith("[")) JSONArray(s) else (JSONObject(s).optJSONArray("items") ?: JSONArray())
        } catch (e: JSONException) {
            // Output was cut off: keep every item that was completed.
            val a = s.indexOf('[')
            val end = s.lastIndexOf('}')
            if (a >= 0 && end > a) {
                try {
                    return JSONArray(s.substring(a, end + 1) + "]")
                } catch (_: JSONException) {
                }
            }
            throw e
        }
    }

    private fun prompt(p: Prefs.Snapshot): String {
        val lang = when (p.source) {
            "zh" -> "Chinese"
            "ko" -> "Korean"
            "en" -> "English"
            "ja" -> "Japanese"
            else -> null
        }
        val sb = StringBuilder()
        sb.append(
            "You are a professional comic translator (manga, manhwa, manhua, webtoon) working for Thai readers. " +
                "The image is a phone screenshot of a comic someone is reading right now. "
        )
        if (lang != null) {
            sb.append("The source text is most likely $lang, but translate any language you find.\n\n")
        } else {
            sb.append("The source language may be Japanese, Chinese, Korean or English; detect it yourself for each text.\n\n")
        }
        sb.append("Find every speech bubble, thought bubble and narration box that is part of the comic artwork")
        if (p.sfx) sb.append(", plus sound effects.\n") else sb.append(". Skip sound effects and decorative lettering.\n")
        sb.append(
            "Ignore the phone and app interface (status bar, toolbars, buttons, navigation), ads, watermarks, " +
                "page numbers, chapter titles shown by the app, and comment sections. " +
                "Skip text that is cut off at the screen edge so badly it cannot be read.\n\n"
        )
        sb.append(
            "For each text return an object:\n" +
                "- \"box\": [ymin, xmin, ymax, xmax] of the whole bubble or box (not only the letters), integers 0-1000 relative to the screenshot height (y) and width (x)\n" +
                "- \"src\": the original text\n" +
                "- \"tr\": the Thai translation\n" +
                "- \"kind\": \"speech\", \"thought\", \"caption\" or \"sfx\"\n\n"
        )
        sb.append(
            "How to translate:\n" +
                "- Write natural spoken Thai the way an official Thai release would. Never translate word for word.\n" +
                "- Infer each speaker's gender, age, personality and relationship from the art and the dialogue, then choose Thai pronouns (ผม ฉัน เรา กู แก นาย เธอ ข้า เจ้า) and sentence-ending particles (ครับ ค่ะ คะ นะ จ้ะ ล่ะ เว้ย วะ) that fit them.\n"
        )
        when (p.tone) {
            1 -> sb.append("- Lean casual and friendly in general; use formal speech only for characters who clearly speak formally.\n")
            2 -> sb.append("- Lean polite (ครับ/ค่ะ) in general; stay rough only for characters who are clearly rude or very close friends.\n")
            else -> {}
        }
        sb.append("- Keep jokes, slang, anger and emotion alive. Keep each line short enough to fit its bubble.\n")
        if (p.honorifics) {
            sb.append("- Keep honorifics and forms of address as Thai transliterations (ซัง คุง จัง เซนไป โอปป้า ออนนี่ ซือฝุ).\n")
        } else {
            sb.append("- Turn honorifics and forms of address into natural Thai (พี่ รุ่นพี่ น้อง คุณ อาจารย์ ท่าน).\n")
        }
        if (p.glossary.isNotBlank()) {
            sb.append("\nCharacter names and terms. Always use these Thai spellings:\n")
            sb.append(p.glossary.trim().take(1500)).append('\n')
        }
        if (history.isNotEmpty()) {
            sb.append("\nRecent lines from this story, so names, pronouns and tone stay consistent:\n")
            for (line in history) sb.append(line).append('\n')
        }
        sb.append(
            "\nReply with JSON only, items in reading order: " +
                "{\"items\":[{\"box\":[ymin,xmin,ymax,xmax],\"src\":\"...\",\"tr\":\"...\",\"kind\":\"speech\"}]}. " +
                "If there is no comic text, reply {\"items\":[]}."
        )
        return sb.toString()
    }

    private fun remember(items: List<Item>) {
        for (it in items) {
            if (it.kind == "sfx") continue
            history.addLast((it.src.take(60) + " => " + it.text.take(60)).replace('\n', ' '))
            while (history.size > 12) history.removeFirst()
        }
    }

    // ---------------- ML Kit fallback ----------------

    private fun getRecognizer(code: String): TextRecognizer = recognizers.getOrPut(code) {
        when (code) {
            "zh" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            "ko" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            "en" -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            else -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        }
    }

    private fun getMlTranslator(code: String): MlTranslator = mlTranslators.getOrPut(code) {
        val srcLang = when (code) {
            "zh" -> TranslateLanguage.CHINESE
            "ko" -> TranslateLanguage.KOREAN
            "en" -> TranslateLanguage.ENGLISH
            else -> TranslateLanguage.JAPANESE
        }
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(srcLang)
                .setTargetLanguage(TranslateLanguage.THAI)
                .build()
        )
    }

    /** ตรวจจับภาษาจากตัวอักษรในกล่องข้อความเมื่อผู้ใช้ตั้งค่าเป็น auto ในโหมดสำรอง */
    private fun detectScriptLang(text: String, fallback: String): String {
        var kana = 0
        var hangul = 0
        var cjk = 0
        var latin = 0
        for (ch in text) {
            val c = ch.code
            when {
                c in 0x3040..0x30FF || c in 0x31F0..0x31FF -> kana++
                c in 0xAC00..0xD7A3 || c in 0x1100..0x11FF || c in 0x3130..0x318F -> hangul++
                c in 0x4E00..0x9FFF -> cjk++
                c in 0x0041..0x005A || c in 0x0061..0x007A -> latin++
            }
        }
        return when {
            hangul > 0 -> "ko"
            kana > 0 -> "ja"
            cjk > 0 && cjk >= latin -> "zh"
            latin > 0 -> "en"
            else -> fallback
        }
    }

    private fun mlkit(bmp: Bitmap, p: Prefs.Snapshot, g: Int): List<Item> {
        val image = InputImage.fromBitmap(bmp, 0)
        val primaryCode = if (p.source == "auto") "ja" else p.source
        var result = Tasks.await(getRecognizer(primaryCode).process(image), 30, TimeUnit.SECONDS)
        ensureAlive(g)

        // หากตั้งเป็น auto แล้วตัวอ่านญี่ปุ่นไม่เจอตัวอักษรญี่ปุ่นเลย ให้ลองตัวอ่านเกาหลีและจีนตามลำดับ
        var activeCode = primaryCode
        if (p.source == "auto") {
            val allText = result.textBlocks.joinToString("") { it.text }
            val detected = detectScriptLang(allText, "ja")
            if (allText.isBlank() || (detected != "ja" && detected != "en")) {
                for (tryCode in listOf("ko", "zh")) {
                    val altRes = Tasks.await(getRecognizer(tryCode).process(image), 30, TimeUnit.SECONDS)
                    ensureAlive(g)
                    val altText = altRes.textBlocks.joinToString("") { it.text }
                    if (altText.length > allText.length) {
                        result = altRes
                        activeCode = tryCode
                        break
                    }
                }
            }
        }

        val topCut = (bmp.height * 0.05).toInt()     // ตัดแถบสถานะด้านบน
        val bottomCut = (bmp.height * 0.93).toInt()  // ตัดแถบนำทางและโฆษณาด้านล่าง
        val out = ArrayList<Item>()
        val downloaded = HashSet<String>()

        for (block in result.textBlocks) {
            val r = block.boundingBox ?: continue
            if (r.bottom <= topCut || r.top >= bottomCut) continue

            val blockLang = if (p.source == "auto") detectScriptLang(block.text, activeCode) else activeCode
            val isVerticalCjk = (blockLang == "ja" || blockLang == "zh") && r.height() > r.width() * 1.15f
            val orderedLines = if (isVerticalCjk && block.lines.size > 1) {
                // มังงะญี่ปุ่น/จีนแนวตั้ง อ่านคอลัมน์จากขวาไปซ้าย
                block.lines.sortedByDescending { it.boundingBox?.centerX() ?: 0 }
            } else {
                block.lines
            }

            val sep = if (blockLang == "en" || blockLang == "ko") " " else ""
            val raw = orderedLines.joinToString(sep) { it.text.trim() }.trim()
            if (raw.isEmpty() || raw.none { it.isLetter() }) continue

            val tl = getMlTranslator(blockLang)
            if (downloaded.add(blockLang)) {
                Tasks.await(tl.downloadModelIfNeeded(DownloadConditions.Builder().build()), 180, TimeUnit.SECONDS)
                ensureAlive(g)
            }
            val tr = Tasks.await(tl.translate(raw), 30, TimeUnit.SECONDS)
            ensureAlive(g)
            if (tr.isNullOrBlank()) continue
            out.add(Item(Rect(r), tr, raw, "speech"))
        }
        return out
    }

    companion object {
        /** Used by the "test key" button on the main screen. Blocking: call it off the main thread. */
        fun testKey(key: String, model: String): String {
            val name = model.trim().removePrefix("models/").ifEmpty { Prefs.DEFAULT_MODEL }
            val body = JSONObject()
                .put(
                    "contents", JSONArray().put(
                        JSONObject().put("role", "user").put(
                            "parts", JSONArray().put(JSONObject().put("text", "Reply with the single word OK"))
                        )
                    )
                )
                .put("generationConfig", JSONObject().put("maxOutputTokens", 64))
                .toString().toByteArray(Charsets.UTF_8)
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/" + name + ":generateContent")
                .openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.setRequestProperty("x-goog-api-key", key.trim())
                c.outputStream.use { it.write(body) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                val detail = try {
                    JSONObject(text).getJSONObject("error").optString("message").take(160)
                } catch (e: Exception) {
                    ""
                }
                return when {
                    code in 200..299 -> "ใช้งานได้ โมเดล " + name + " ตอบกลับปกติ"
                    code == 429 -> "key ใช้ได้ แต่โควตาฟรีของโมเดลนี้หมดชั่วคราว ลองใหม่ภายหลัง"
                    code == 401 || code == 403 || (code == 400 && detail.contains("API key", ignoreCase = true)) ->
                        "key ใช้ไม่ได้ ($code) ตรวจว่าคัดลอกมาครบ " + detail
                    code == 404 -> "ไม่พบโมเดล " + name + " ลองลบช่องโมเดลให้ว่างเพื่อใช้ค่าเริ่มต้น"
                    else -> "ผิดพลาด ($code) " + detail
                }
            } finally {
                try { c.disconnect() } catch (_: Exception) {}
            }
        }
    }
}
