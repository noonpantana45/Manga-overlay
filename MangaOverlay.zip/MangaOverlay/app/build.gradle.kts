plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mangaoverlay.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mangaoverlay.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.2"
    }

    // Fixed key so every new build installs over the old one and keeps your settings.
    signingConfigs {
        create("main") {
            storeFile = file("manga.keystore")
            storePassword = "mangaoverlay"
            keyAlias = "manga"
            keyPassword = "mangaoverlay"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("main")
        }
        debug {
            signingConfig = signingConfigs.getByName("main")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // Offline fallback: on-device text recognition + translation (Google ML Kit, free)
    implementation("com.google.mlkit:text-recognition:16.0.0")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.0")
    implementation("com.google.mlkit:text-recognition-japanese:16.0.0")
    implementation("com.google.mlkit:text-recognition-korean:16.0.0")
    implementation("com.google.mlkit:translate:17.0.2")
}
